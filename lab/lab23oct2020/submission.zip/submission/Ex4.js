var values = [1,60,34,30,20,5];
var filterLessThan20 = values.filter(number => number < 20);
console.log(filterLessThan20);